console.log('ZOO Solana wallet JS loaded');

(function () {
  'use strict';

  const splToken = window.splToken;
  if (!splToken) {
    console.warn('[ZOO] @solana/spl-token not on window (CSP may block unpkg). Checkout still works: transfers use web3-only ix.');
  }

  // Defaults match wp_localize_script (mainnet); zoo_ajax overrides when present.
  const DEFAULT_RPC = 'https://api.mainnet-beta.solana.com';
  const ZOO_MINT = 'zoofwvSp4VepYrNBhUUcuGbkhYyqgrS2NhAMYniQZeA';
  const SHOP_WALLET = 'F6FSKFnryX4g8kDeapfXRJ4KRJ7F9oTFUih1QbQ7gktA';

  function getRpcUrl() {
    const u = String(getZooAjax().rpc_url || '').trim();
    return u || DEFAULT_RPC;
  }

  function getZooMintStr() {
    const m = String(getZooAjax().zoo_mint || '').trim();
    return m || ZOO_MINT;
  }

  function getShopWalletStr() {
    const s = String(getZooAjax().shop_wallet || '').trim();
    return s || SHOP_WALLET;
  }

  function getSolanaNetwork() {
    const n = String(getZooAjax().solana_network || '').trim();
    return n || 'mainnet-beta';
  }

  /** WooCommerce leaves the form “processing” / disables #place_order after Place order; unlock when our async flow ends. */
  let zooPayInFlight = false;
  function zooUnlockCheckoutUi() {
    if (typeof jQuery === 'undefined') return;
    const $form = jQuery('form.checkout');
    $form.removeClass('processing');
    try {
      if (typeof $form.unblock === 'function') {
        $form.unblock();
      }
    } catch (e) { /* ignore */ }
    jQuery('#place_order').prop('disabled', false).removeClass('disabled');
  }

  const connectBtn = document.getElementById('connect-wallet-btn');
  const msgSpan = document.getElementById('zoo-wallet-msg') || document.getElementById('zoo-header-wallet-msg');
  let publicKey = null;

  function getZooAjax() {
    return window.zoo_ajax || {};
  }

  function getOrderTotal() {
    const el = document.querySelector('.order-total .woocommerce-Price-amount');
    if (!el) return 0;
    const total = el.textContent.replace(/[^0-9.]/g, '');
    return parseFloat(total) || 0;
  }

  function generateSolanaPayQR(amount) {
    const merchantWallet = getShopWalletStr();
    const mint = getZooMintStr();
    const solanaWeb3 = window.solanaWeb3;
    if (!solanaWeb3) return;
    const reference = solanaWeb3.Keypair.generate().publicKey.toString();
    const url = 'solana:' + merchantWallet +
      '?amount=' + amount +
      '&spl-token=' + mint +
      '&reference=' + reference;
    const qrDiv = document.getElementById('zoo-qr');
    if (!qrDiv) return;
    qrDiv.innerHTML = '';
    if (typeof QRCode !== 'undefined') {
      new QRCode(qrDiv, { text: url, width: 180, height: 180 });
    }
  }

  function showMsg(message, isError) {
    if (msgSpan) {
      msgSpan.textContent = message || '';
      msgSpan.style.color = isError ? 'red' : 'lime';
    }
  }

  function isPhantomInstalled() {
    return window.solana && window.solana.isPhantom;
  }

  function updateWalletUI() {
    const pill = document.getElementById('connect-wallet-btn');
    if (!pill || !publicKey) return;
    pill.innerText =
      publicKey.slice(0, 4) + '...' +
      publicKey.slice(-4);
  }

  function updateUIConnected() {
    if (publicKey) {
      showMsg('Wallet Connected', false);
      updateWalletUI();
    }
  }

  function syncPublicKey(pk) {
    publicKey = pk;
    window.publicKey = pk;
  }

  async function fetchZooBalance(wallet) {
    // Use global loaded by Woo enqueue (window.solanaWeb3); bare solanaWeb3 is not in scope in IIFE
    const solanaWeb3 = window.solanaWeb3;
    if (!solanaWeb3) return;

    const connection = new solanaWeb3.Connection(getRpcUrl(), 'confirmed');

    const mint = new solanaWeb3.PublicKey(getZooMintStr());

    const accounts =
      await connection.getParsedTokenAccountsByOwner(
        new solanaWeb3.PublicKey(wallet),
        { mint }
      );

    let balance = 0;

    if (accounts.value.length) {
      balance =
        accounts.value[0]
          .account.data.parsed.info.tokenAmount.uiAmount;
    }

    const zooBalanceEl = document.getElementById('zoo-balance');
    if (zooBalanceEl) {
      zooBalanceEl.innerText = balance + ' ZOO';
    }

    const badge = document.querySelector('#zoo-balance-badge');
    if (badge) badge.innerText = (balance != null ? balance : 0).toFixed(2) + ' ZOO';
  }

  function updateBalanceBadge() {
    if (publicKey) return fetchZooBalance(publicKey);
  }

  function sleep(ms) {
    return new Promise(function (resolve) {
      setTimeout(resolve, ms);
    });
  }

  /** Match Render server math: decimal string → raw base units (no float drift). */
  function decimalStringToRawBigInt(amountStr, decimals) {
    const dec = Number(decimals);
    if (!Number.isFinite(dec) || dec < 0) return null;
    const str = String(amountStr || '').trim();
    if (!/^\d+(\.\d+)?$/.test(str)) return null;
    const parts = str.split('.');
    const whole = parts[0] || '0';
    const frac = (parts[1] || '').slice(0, dec).padEnd(dec, '0');
    try {
      return BigInt(whole + frac);
    } catch (e) {
      return null;
    }
  }

  /** SPL Associated Token Program — same as @solana/spl-token ASSOCIATED_TOKEN_PROGRAM_ID */
  const ASSOCIATED_TOKEN_PROGRAM_STR = 'ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL';

  function getAssociatedTokenAddressSync(solanaWeb3, mint, owner, tokenProgramId, associatedTokenProgramId) {
    const [address] = solanaWeb3.PublicKey.findProgramAddressSync(
      [owner.toBuffer(), tokenProgramId.toBuffer(), mint.toBuffer()],
      associatedTokenProgramId
    );
    return address;
  }

  /** Create shop ATA if missing; idempotent — ok when ATA already exists. Buyer pays rent. */
  function createAssociatedTokenAccountIdempotentInstruction(solanaWeb3, payer, associatedToken, owner, mint, tokenProgramId, associatedTokenProgramId) {
    return new solanaWeb3.TransactionInstruction({
      programId: associatedTokenProgramId,
      keys: [
        { pubkey: payer, isSigner: true, isWritable: true },
        { pubkey: associatedToken, isSigner: false, isWritable: true },
        { pubkey: owner, isSigner: false, isWritable: false },
        { pubkey: mint, isSigner: false, isWritable: false },
        { pubkey: solanaWeb3.SystemProgram.programId, isSigner: false, isWritable: false },
        { pubkey: tokenProgramId, isSigner: false, isWritable: false }
      ],
      data: new Uint8Array([1])
    });
  }

  async function connectWallet() {
    if (!isPhantomInstalled()) {
      showMsg('Phantom Wallet not installed.', true);
      return;
    }
    try {
      const resp = await window.solana.connect();
      syncPublicKey(resp.publicKey.toString());
      updateUIConnected();
      await fetchZooBalance(publicKey);
    } catch (e) {
      showMsg('Wallet connection rejected.', true);
    }
  }

  async function autoConnectWallet() {
    if (!isPhantomInstalled()) return;
    try {
      const resp = await window.solana.connect({ onlyIfTrusted: true });
      if (resp && resp.publicKey) {
        syncPublicKey(resp.publicKey.toString());
        updateWalletUI();
        updateUIConnected();
        await fetchZooBalance(publicKey);
      } else {
        showMsg('Ready to connect.', false);
      }
    } catch (e) {
      console.log('Wallet not yet trusted');
      showMsg('Ready to connect.', false);
    }
  }

  async function sendZooPayment(amount) {
    if (!window.solana) throw new Error('Phantom not found');
    const solanaWeb3 = window.solanaWeb3;
    if (!solanaWeb3) throw new Error('Solana Web3 not loaded');

    const provider = window.solana;
    if (!provider.isPhantom) throw new Error('Phantom wallet not found');
    if (typeof provider.signAndSendTransaction !== 'function') {
      console.error('Phantom wallet does not support signAndSendTransaction');
      throw new Error('Phantom does not support signAndSendTransaction');
    }

    const connection = new solanaWeb3.Connection(getRpcUrl(), 'confirmed');
    const fromPubKey = new solanaWeb3.PublicKey(publicKey);
    const toPubKey = new solanaWeb3.PublicKey(getShopWalletStr());
    const mintPubKey = new solanaWeb3.PublicKey(getZooMintStr());
    const TOKEN_PROGRAM_ID = new solanaWeb3.PublicKey('TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA');

    const fromTokens = await connection.getTokenAccountsByOwner(fromPubKey, { mint: mintPubKey });
    if (!fromTokens.value.length) throw new Error('No ZOO token account in wallet');

    const associatedTokenProgramId = new solanaWeb3.PublicKey(ASSOCIATED_TOKEN_PROGRAM_STR);
    const shopTokenAccount = getAssociatedTokenAddressSync(
      solanaWeb3,
      mintPubKey,
      toPubKey,
      TOKEN_PROGRAM_ID,
      associatedTokenProgramId
    );

    const ajax = getZooAjax();
    const dec = Number.isFinite(Number(ajax.decimals)) ? Number(ajax.decimals) : 9;
    const amountStr = typeof amount === 'string' ? amount.trim() : String(amount);
    const rawBig = decimalStringToRawBigInt(amountStr, dec);
    if (!rawBig || rawBig <= 0n) {
      throw new Error('Invalid payment amount');
    }
    const data = new Uint8Array(9);
    data[0] = 3;
    new DataView(data.buffer).setBigUint64(1, rawBig, true);

    const transferIx = new solanaWeb3.TransactionInstruction({
      keys: [
        { pubkey: fromTokens.value[0].pubkey, isSigner: false, isWritable: true },
        { pubkey: shopTokenAccount, isSigner: false, isWritable: true },
        { pubkey: fromPubKey, isSigner: true, isWritable: false }
      ],
      programId: TOKEN_PROGRAM_ID,
      data: data
    });

    const createAtaIx = createAssociatedTokenAccountIdempotentInstruction(
      solanaWeb3,
      fromPubKey,
      shopTokenAccount,
      toPubKey,
      mintPubKey,
      TOKEN_PROGRAM_ID,
      associatedTokenProgramId
    );

    const tx = new solanaWeb3.Transaction().add(createAtaIx).add(transferIx);
    const latest = await connection.getLatestBlockhash();
    tx.recentBlockhash = latest.blockhash;
    tx.feePayer = fromPubKey;

    console.log('[ZOO] Sending transaction via Phantom...');
    const signedTx = await provider.signAndSendTransaction(tx);
    console.log('[ZOO] Transaction sent:', signedTx.signature);
    await connection.confirmTransaction(signedTx.signature, 'finalized');
    return signedTx.signature;
  }

  window.sendZooTokens = function (fromPubkeyStr, amount) {
    return sendZooPayment(amount);
  };

  async function payWithZoo(amountParam) {
    if (zooPayInFlight) {
      console.log('[ZOO] Payment already in progress');
      return false;
    }
    zooPayInFlight = true;
    try {
    console.log('[ZOO] Attempting payment...');
    if (!isPhantomInstalled()) {
      console.log('[ZOO] Phantom not installed');
      alert('Phantom Wallet is not installed!');
      showMsg('Phantom Wallet not installed.', true);
      return false;
    }
    if (!publicKey) {
      console.log('[ZOO] Wallet not connected');
      showMsg('Connect your wallet first.', true);
      alert('Connect your wallet first!');
      return false;
    }
    const ajax = getZooAjax();
    const shopOwnerForGuard = String(ajax.shop_wallet || getShopWalletStr() || '').trim();
    if (shopOwnerForGuard && publicKey === shopOwnerForGuard) {
      const msg = 'Use a buyer wallet in Phantom — not the shop wallet. Your shop address is the receiver; paying with the same key does not work for real customers.';
      console.warn('[ZOO]', msg);
      showMsg(msg, true);
      alert(msg);
      return false;
    }
    const amount = (amountParam != null && amountParam > 0) ? Number(amountParam) : (getOrderTotal() || parseFloat(ajax.order_amount) || 0);
    if (!amount || amount <= 0) {
      console.log('[ZOO] Invalid order amount:', amount);
      showMsg('Invalid order amount.', true);
      return false;
    }
    console.log('[ZOO] Sending ' + amount + ' ZOO...');
    showMsg('Processing TX...', false);
    if (connectBtn) {
      connectBtn.classList.add('pending');
      connectBtn.classList.remove('failed', 'success');
    }
    try {
      // 1) Create pending order first (get order_id for verify)
      const ajaxUrl = ajax.ajax_url || '/wp-admin/admin-ajax.php';
      const createBody = new URLSearchParams({
        action: 'zoo_create_pending_order',
        nonce: ajax.create_order_nonce || '',
        zoo_wallet_address: publicKey
      }).toString();
      const orderResp = await fetch(ajaxUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: createBody
      });
      const orderData = await orderResp.json();
      if (!orderData.success) throw new Error(orderData.data?.message || 'Could not create order');
      const orderId = (orderData.data && orderData.data.order_id) || orderData.order_id;
      const redirectUrl = (orderData.data && (orderData.data.redirect_url || orderData.data.redirect)) || '/checkout/order-received/' + orderId + '/';
      const serverTotalRaw = (orderData.data && orderData.data.total) || orderData.total;
      const serverTotalStr = String(serverTotalRaw == null ? '' : serverTotalRaw).trim();
      const serverTotal = parseFloat(serverTotalStr);
      if (!orderId) throw new Error('No order ID returned');
      if (!serverTotalStr || !serverTotal || serverTotal <= 0) throw new Error('Invalid order total returned from server');
      console.log('[ZOO] Order created:', orderId);

      // 2) Phantom – sign & send transaction (string total avoids float drift vs verifier)
      const txSignature = await window.sendZooTokens(publicKey, serverTotalStr);
      console.log('[ZOO] Payment successful, tx:', txSignature);

      // 3) Verify (store pending; cron will confirm on-chain)
      const verifyPayload = {
        signature: txSignature,
        order_id: orderId,
        expectedAmount: serverTotalStr,
        network: getSolanaNetwork()
      };
      console.log('[ZOO] Verifying payment...', verifyPayload);
      let verifyData = null;
      let lastVerifyText = '';
      let lastVerifyStatus = 0;
      for (let attempt = 1; attempt <= 5; attempt++) {
        const verifyResp = await fetch('/wp-json/zoo/v1/verify-render', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(verifyPayload)
        });
        lastVerifyStatus = verifyResp.status;
        lastVerifyText = await verifyResp.text().catch(function () { return ''; });
        verifyData = {};
        if (lastVerifyText) {
          try {
            verifyData = JSON.parse(lastVerifyText);
          } catch (parseErr) {
            verifyData = {
              success: false,
              message: 'verify-render returned non-JSON (HTTP ' + lastVerifyStatus + ')',
              raw_preview: lastVerifyText.slice(0, 400)
            };
          }
        }
        if (verifyResp.ok && verifyData && verifyData.success) break;

        const msg = String((verifyData && (verifyData.message || verifyData.error)) || '').toLowerCase();
        const retryable = msg.includes('not finalized') || msg.includes('invalid transaction') || msg.includes('error verifying transaction');
        if (attempt < 5 && retryable) {
          await sleep(2000);
          continue;
        }
        break;
      }
      console.log('Verification Response:', verifyData);

      if (verifyData && verifyData.success) {
        await Promise.all([
          (async function () {
            const wooVerifyRes = await fetch("/wp-json/zoo/v1/verify-payment", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                order_id: Number(orderId),
                signature: txSignature
              })
            });
            const wooVerifyData = await wooVerifyRes.json().catch(() => ({}));
            if (!wooVerifyRes.ok || !wooVerifyData.success) {
              throw new Error((wooVerifyData && wooVerifyData.message) || 'WooCommerce order update failed');
            }
          })()
        ]);
      } else {
        const extra =
          (verifyData && verifyData.render_body) ? String(verifyData.render_body) :
          (verifyData && verifyData.raw_preview) ? String(verifyData.raw_preview) : '';
        let detail =
          (verifyData && (verifyData.message || verifyData.error)) ||
          extra ||
          (lastVerifyText ? ('HTTP ' + lastVerifyStatus + ': ' + lastVerifyText.slice(0, 240)) : ('HTTP ' + lastVerifyStatus));
        if (verifyData && verifyData.success === false && !verifyData.message && !verifyData.error) {
          detail = 'Verifier returned {"success":false} with no details. Your Render service is not running the current server.js. Deploy woo-solana-payment-devnet from GitHub, then open https://woo-solana-payment-devnet.onrender.com/api-meta — you should see JSON with "version":2 (404 = old deploy).';
        }
        throw new Error(detail || 'Verification failed');
      }

      // 4) Redirect
      window.location.href = redirectUrl;
    } catch (err) {
      console.error('[ZOO] Payment error:', err);
      if (connectBtn) {
        connectBtn.classList.remove('pending');
        connectBtn.classList.add('failed');
        setTimeout(function () { connectBtn.classList.remove('failed'); }, 1000);
      }
      showMsg(err.message || 'TX failed', true);
      alert('Payment failed: ' + (err.message || 'Unknown error'));
      return false;
    }
    return true;
    } finally {
      zooPayInFlight = false;
      zooUnlockCheckoutUi();
    }
  }

  function checkoutWithZoo() {
    return payWithZoo();
  }

  if (connectBtn) connectBtn.addEventListener('click', connectWallet);

  function openZooModal() {
    const modal = document.getElementById('zoo-payment-modal');
    if (!modal) return;
    modal.style.display = 'flex';
    const total = getOrderTotal();
    const totalEl = document.getElementById('zoo-order-total');
    if (totalEl) totalEl.innerText = total + ' ZOO';
    const addrEl = document.getElementById('zoo-wallet-address');
    if (addrEl) addrEl.textContent = publicKey ? publicKey.slice(0, 6) + '…' + publicKey.slice(-4) : '—';
    const balanceEl = document.getElementById('zoo-balance');
    if (balanceEl) balanceEl.textContent = document.querySelector('#zoo-balance-badge') ? document.querySelector('#zoo-balance-badge').innerText : '—';
    generateSolanaPayQR(total);
  }

  function closeZooModal() {
    const modal = document.getElementById('zoo-payment-modal');
    if (modal) modal.style.display = 'none';
  }

  document.addEventListener('DOMContentLoaded', function () {
    // Place Order with selected ZOO gateway id (keep legacy zoo_devnet hook for compatibility)
    if (typeof jQuery !== 'undefined') {
      jQuery(function ($) {
        const ajax = getZooAjax();
        const activeGatewayId = String(ajax.gateway_id || 'zoo_devnet');
        const legacyGatewayId = String(ajax.legacy_gateway_id || 'zoo_devnet');
        const eventNames = [`checkout_place_order_${activeGatewayId}`];
        if (legacyGatewayId && legacyGatewayId !== activeGatewayId) {
          eventNames.push(`checkout_place_order_${legacyGatewayId}`);
        }
        eventNames.forEach(function (eventName) {
          $('form.checkout').on(eventName, function () {
            payWithZoo();
            return false;
          });
        });
      });
    }

    // "Pay From This Browser" – get amount and trigger payment
    const confirmBtn = document.getElementById('zoo-confirm-payment');
    if (confirmBtn) {
      confirmBtn.addEventListener('click', async function () {
        const amount = getOrderTotal();
        if (!amount) {
          alert('Invalid order amount');
          return;
        }
        if (confirmBtn.disabled) return;
        confirmBtn.disabled = true;
        try {
          await payWithZoo(amount);
        } finally {
          confirmBtn.disabled = false;
        }
      });
    }

    // Cancel – close modal
    const closeBtn = document.getElementById('zoo-close-modal');
    if (closeBtn) {
      closeBtn.addEventListener('click', closeZooModal);
    }
  });

  // Expose for debugging (e.g. window.payWithZoo() in console)
  window.payWithZoo = payWithZoo;

  // Phantom auto reconnect silently (onlyIfTrusted)
  document.addEventListener('DOMContentLoaded', async function () {
    if (window.solana && window.solana.isPhantom) {
      try {
        const resp = await window.solana.connect({
          onlyIfTrusted: true
        });
        window.publicKey = resp.publicKey.toString();
        syncPublicKey(window.publicKey); // keep local publicKey in sync for payWithZoo
        updateWalletUI();
        await fetchZooBalance(publicKey);
      } catch (e) {
        console.log('Wallet not yet trusted');
      }
    }
  });
})();
